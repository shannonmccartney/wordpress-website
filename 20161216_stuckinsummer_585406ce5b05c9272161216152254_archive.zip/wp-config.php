<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'McCartney');

/** MySQL database password */
define('DB_PASSWORD', 'soccer34');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'BUB82g#u2:+)EZ`9_.=0 xt&QS!:S=.T$]b7%o!Ql&uW%ct!dc<#/UdSV((1f]c&');
define('SECURE_AUTH_KEY',  '%~!VF*NO+Q%my]l#PIA}V~Z?OR4~vME5U(:,Jt*ri~+UN|Y@s+)P*+zNX<HH,33C');
define('LOGGED_IN_KEY',    'wH3D(GmRl}M cG[$:eO8ne>nVUq81=4c^Qr&+tfc[N#JSK{THsnm: gGzym}#rKf');
define('NONCE_KEY',        'I10<A^1dHua>BT<(s-O1GWqN7ao}M}QBZPHZ%|R~:Qzz8@7p(6gSJP4uoeV{9}L ');
define('AUTH_SALT',        '2&e+sfJ`KZ%LJVI`p*y:2j?4 {x|RYt9wLC|:mR`,.yqEpY4b(-%l5TS9DXB}-q&');
define('SECURE_AUTH_SALT', 'Pul5]Qp2]f]]|22$!E~N p(;WQtG3)pHfre;70ngg<V5lgmN[ZvG1NQzg^rQ5^Iu');
define('LOGGED_IN_SALT',   ']:,x0w29x8I34ajCW}$gVDro29`FK.e@e|$$%)Gd67NyH)D4;h#~CAyqx;{2Y{=E');
define('NONCE_SALT',       'NArW>SbsK<%65>*VF}#-g^~X7`Bz.@ioe7B&17E2O%(:4dQ_FoLJ~7IpvG.zq~:R');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
